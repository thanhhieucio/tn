{
    'name': 'TN-ITC',
    'version': '1',
    'summary': 'Phần Mềm Quản Lý Bán Hàng',
    'sequence': 2,
    'description': '',
    'category': '',
    'author': '',
    'website': '',
    'license': 'LGPL-3',
    'depends': [
        'base',
    ],
    'data': [
        'views/sanpham.xml',
        'views/nhomsanpham.xml',
        'views/donvitinh.xml',
        'views/khachhang.xml',
        'views/khuvuc.xml',
        'views/noidungthuchi.xml'
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}